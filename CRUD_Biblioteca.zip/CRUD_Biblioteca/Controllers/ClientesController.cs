﻿using CRUD_Biblioteca.data;
using CRUD_Biblioteca.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace CRUD_Biblioteca.Controllers
{
    public class ClientesController : Controller
    {
        private readonly AppDbContext _context;

        public ClientesController(AppDbContext context)
        {
            _context = context;
        }

  
        public async Task<IActionResult> ClientesIndex()
        {
            var clientes = await _context.Clientes.ToListAsync();
            return View(clientes);
        }

   
        public IActionResult Create()
        {
            return View();
        }

    
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Usuario usuario)
        {
            if (ModelState.IsValid)
            {

                
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(ClientesIndex));
            }
            return View(usuario);
        }


        public async Task<IActionResult> Edit(int id)
        {
            var usuario = await _context.Clientes.FindAsync(id);
            if (usuario == null)
            {
                return NotFound();
            }
            return View(usuario);
        }

      
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Usuario usuario)
        {
            if (id != usuario.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(usuario);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UsuarioExists(usuario.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(ClientesIndex));
            }
            return View(usuario);
        }

        // GET: Clientes/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var usuario = await _context.Clientes.FindAsync(id);
            if (usuario == null)
            {
                return NotFound();
            }
            return View(usuario);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var usuario = await _context.Clientes.FindAsync(id);
            if (usuario != null)
            {
                _context.Clientes.Remove(usuario);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(ClientesIndex));
        }

        
        public async Task<IActionResult> Details(int id)
        {
            var usuario = await _context.Clientes
                .FirstOrDefaultAsync(m => m.Id == id);
            if (usuario == null)
            {
                return NotFound();
            }

            return View(usuario);
        }

        private bool UsuarioExists(int id)
        {
            return _context.Clientes.Any(e => e.Id == id);
        }
    }
}
