﻿namespace CRUD_Biblioteca.Models
{
    public class Pedido
    {
        public int pedidoId { get; set; }
        public string DescrpcionPedido { get; set; }
        public DateTime FechaPedido { get; set; }

    }
}
