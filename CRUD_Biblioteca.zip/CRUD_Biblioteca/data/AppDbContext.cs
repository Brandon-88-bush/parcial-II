﻿using CRUD_Biblioteca.Models;
using Microsoft.EntityFrameworkCore;

namespace CRUD_Biblioteca.data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Libro> Libros { get; set; }

        public DbSet<Usuario>Usuarios { get; set; }
         public DbSet<Cliente>Clientes { get; set; }

        public DbSet<Pedido>Pedidos { get; set; }
    }
}
