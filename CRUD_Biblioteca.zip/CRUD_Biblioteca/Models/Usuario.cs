﻿namespace CRUD_Biblioteca.Models
{
    public class Usuario
    {
        public int Id { get; set; }
        
        public string Name { get; set; }
        public int Edad { get; set; }
        public int Tell { get; set; }
    }
}
