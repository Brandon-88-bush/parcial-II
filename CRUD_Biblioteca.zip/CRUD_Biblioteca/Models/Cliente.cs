﻿using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages.Manage;

namespace CRUD_Biblioteca.Models
{
    public class Cliente
    {
        public int Id { get; set; }

        public string Name { get; set; }
        public Email Gmail { get; set; }
        public int Tell { get; set; }
    }
}
