﻿using CRUD_Biblioteca.data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CRUD_Biblioteca.Controllers
{
    public class UsuariosController: Controller
   
    {
        private readonly AppDbContext _context;

        public UsuariosController(AppDbContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Usuario()
        {
            var Usuarios = await _context.Usuarios.ToListAsync();
            return View(Usuarios);

        }
    }
}
