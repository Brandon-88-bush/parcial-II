﻿using Microsoft.AspNetCore.Mvc;
using NuGet.Protocol.Plugins;
using System.ComponentModel.DataAnnotations;
using System.Reflection.Metadata.Ecma335;


namespace CRUD_Biblioteca.Models
{
    public class Libro
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El libro necesita un titulo")]
        [StringLength(100, ErrorMessage = "El titulo no puede superar los 50 caracteres")]

        public required string Titulo { get; set; }


        public decimal Precio { get; set; }
        public int CantidadPro { get; set; }
    }


    }





